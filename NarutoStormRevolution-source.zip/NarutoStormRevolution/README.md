# Naruto Storm Revolution — Android frontend prototype

Version: 0.1.0-prototype

## Current status

This is a starter Android project for the proposed Naruto Storm Revolution frontend. It is **not yet an Xbox 360 emulator** and does not include Xenia/Xendroid native code. The current app provides:

- a dark branded Android interface;
- file picker for user-owned game files;
- saved local UI choices for internal-resolution scale and 20/30/60 FPS preference;
- an experimental intent bridge to a separately installed Xendroid+ build;
- explanatory UI for Turnip compatibility limitations.

The resolution and FPS choices are not yet connected to the emulator's TOML configuration. The bridge must be tested against the exact Xendroid+ release, and the core must be integrated/forked before these settings can affect gameplay.

## Device target

Samsung Galaxy A52 4G (Snapdragon 720G / Adreno 618) is the initial target. Xendroid+ primarily targets Adreno 7xx/8xx with Turnip; successful emulation and Turnip operation on Adreno 618 are not guaranteed.

## Build in Android Studio

1. Install Android Studio with Android SDK Platform 35 and a JDK 17-compatible toolchain.
2. Open this folder as an existing Gradle project.
3. Allow Gradle to download the Android Gradle Plugin and dependencies.
4. Build with **Build > Make Project**, or from a configured environment run:

   ```bash
   gradle :app:assembleDebug
   ```

5. The debug APK should appear at `app/build/outputs/apk/debug/app-debug.apk`.

This environment did not have Android SDK/Gradle installed and could not reach GitHub, so an APK build has **not** been run or verified here. No APK is included in this archive.

## Planned next milestones

1. Pin a specific Xendroid+ commit/release and inspect its license and build instructions.
2. Fork/integrate the native emulator core and preserve all third-party notices/licenses.
3. Connect UI controls to the supported Xenia config keys (e.g. framerate limit) and confirm the exact resolution-scaling key from the selected source revision.
4. Verify the file picker / URI handoff against that revision.
5. Add driver package validation and only expose Turnip on supported hardware.
6. Build, install, capture logs and test Naruto Shippuden: Ultimate Ninja Storm Revolution from a user-owned dump.

## Legal and safety notes

The project does not distribute game files, console firmware, BIOS, keys, or driver binaries. Use game dumps you are legally entitled to use and retain the licenses/attributions of upstream projects.
